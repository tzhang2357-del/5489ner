# 角色 B 最终交付

本包对应组仓库提交 f80761d3463e9c1f95360b8a3be0dead3b21a3f8。四组预测、A 的评分实现与 C 的实验记录已核对。报告使用英文，供小组合稿。 [组仓库快照](https://github.com/tzhang2357-del/5489ner/tree/f80761d3463e9c1f95360b8a3be0dead3b21a3f8)

| 组员使用场景 | 文件 |
|---|---|
| 合并报告与图表 | report_role_b.md、results/final/four_experiments.png |
| 更新仓库 results/metrics.csv | results/final/metrics.csv。复算修正 E1 的 FP 为 1,003、E3 的 FP 为 1,324，并补齐 E3 的三档长度召回率 |
| 查看分歧例句与错误数量 | results/paired/error_cases.csv、results/paired/error_summary.json |
| 接入 A 的预测入口 | 把 results/e1_full/model.joblib 和 results/e3_shared/model.joblib 分别复制到组仓库 models/crf_full.joblib 和 models/crf_10pct.joblib。当前仓库 src/train_crf.py 已提供配套特征函数 |
| 查看原始实验与配置 | 两个 CRF 实验目录均包含 model.joblib、metrics.json 和 test_predictions.jsonl |
| 查阅正式子集 | train_10pct_ids.shared.json。与原 CRF 子集逐字节相同，两次训练结果均可直接使用 |

## 本地复现

从本目录运行。REPO 指向指定提交的组仓库，DATA 指向包含三份原始 Parquet 文件的目录。C 的预测省略了 tokens，脚本用已核验哈希的测试集按句子 ID 恢复词序列，检查 ID 完整性和逐词标签数。来源与统计协议见报告。

```bash
python -m pip install -r requirements.txt pandas==2.2.3 matplotlib==3.9.4
REPO=/path/to/5489ner
DATA=/path/to/parquet
python train_crf.py --train "$DATA/conll2003-train.parquet" --validation "$DATA/conll2003-validation.parquet" --test "$DATA/conll2003-test.parquet" --output-dir rerun/full
python train_crf.py --train "$DATA/conll2003-train.parquet" --validation "$DATA/conll2003-validation.parquet" --test "$DATA/conll2003-test.parquet" --subset-ids train_10pct_ids.shared.json --output-dir rerun/shared
python finalize_results.py "$REPO" "$DATA/conll2003-test.parquet" rerun/final
python analyze_errors.py --test "$DATA/conll2003-test.parquet" --crf "$REPO/results/predictions/e1_crf_full_test.jsonl" --bert "$REPO/results/predictions/e2_bert_full_test.jsonl" --output-dir rerun/paired
python plot_comparison.py rerun/final/four_scores.json rerun/final/four_experiments.png
```

## 评分标准补充实验

新增实验使用 946 篇训练新闻的文档 ID。先在训练集内部按整篇文档做三折交叉验证选 CRF 正则化参数，再用选定参数在全部训练句上分别训练四种特征配置，并在官方验证集比较。补充实验的程序只接收训练集与验证集。原四组实验的测试结果在报告中单独列出。

```bash
python extension_experiments.py "$DATA/conll2003-train.parquet" "$DATA/conll2003-validation.parquet" results/extensions/train_document_ids.json rerun/extensions
python plot_extensions.py "$DATA/conll2003-train.parquet" rerun/extensions
```

文档映射已随包提供。若要从带 `-DOCSTART-` 的英文训练文本重建映射，可运行 `python recover_document_ids.py eng.train "$DATA/conll2003-train.parquet" recovered.json`。映射过程按原顺序逐词核对全部 14,041 句。 [文档边界来源](https://github.com/patverga/torch-ner-nlp-from-scratch/blob/master/data/conll2003/eng.train)

在 `results/extensions/` 中，`cv.csv` 保存每折分数及样本标准差，`folds.csv` 保存每个训练句的验证折编号，`ablation.csv` 保存四种特征配置的总体和分类 F1。验证集预测按配置单独保存。`full_D.joblib` 的推理需使用 D 对应的特征变换和 `cluster_lookup.json`。

## 稳健性实验与汇报口径

本次新增内容在报告最后两节。原四组主实验表使用测试集，三折调参表使用训练集内部留出折，多种子和按文档重采样结果使用官方验证集。三个口径分别用于比较模型、选参数和检验结论对抽样的敏感程度。

脚本用种子 42–51 重训十个 10% CRF，另在三个文档折内分别拟合 C、D 两版。每折单独学习词簇。验证区间基于 216 篇新闻的配对 bootstrap，保留同一篇文章内全部句子和实体。原始结果及图在 `results/robustness/`。验证文档映射随包附上，由带分隔符的原始文本逐词核对生成。 [验证文档边界来源](https://github.com/patverga/torch-ner-nlp-from-scratch/blob/master/data/conll2003/eng.testa)

```bash
python robustness.py "$DATA/conll2003-train.parquet" "$DATA/conll2003-validation.parquet" results/extensions train_10pct_ids.shared.json results/robustness/validation_document_ids.json rerun/robustness
python plot_robustness.py rerun/robustness
```
