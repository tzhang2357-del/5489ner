# 角色 B 的 CRF 基线与错例分析

本目录包含英文 CoNLL‑2003 上的 CRF 实现、全量模型及预测、10% 暂定子集的实验，以及错例分析脚本。`report_role_b.md` 是英文报告草稿，可直接供小组整合。

## 交付状态

| 内容 | 文件或目录 | 状态 |
|---|---|---|
| CRF 全量训练与评分 | `results/e1_full/` | 已完成本地评分，可交 A 复算 |
| CRF 10% 训练与评分 | `results/e3_provisional/` | 用暂定的 1,404 句样本完成，可在 A 确认同批 ID 后用于组内对照 |
| 10% 样本 ID 建议稿 | `train_10pct_ids.proposed.json` | 使用 Python `random.Random(42)` 从公开训练集无放回抽取 1,404 句，按数据集原顺序保存 |
| 全量 CRF 错例分析 | `results/crf_error_analysis/` | 已统计完整测试集，CSV 保存固定种子抽取的 20 条错例 |
| CRF 与 BERT 对照分析 | `analyze_errors.py` | 收到 C 的全量测试预测后即可按样本 ID 对齐生成 |

## 环境和数据

代码已在 Python 3.9 上运行。安装依赖后，把小组共享的三个 Parquet 文件放到 `data/`。当前实验使用 `eriktks/conll2003` 的 `e8237f8875e4ecf7f60b07ae49691b85cf893410` 快照。 `metrics.json` 记录了每个数据文件的 SHA‑256、候选配置和库版本。 [三份 CoNLL‑2003 Parquet 文件](https://huggingface.co/datasets/eriktks/conll2003/tree/e8237f8875e4ecf7f60b07ae49691b85cf893410/conll2003)

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## 复现训练及导出

在本目录执行。每次训练使用一个新的输出目录。每组完毕后会保存模型、验证与测试指标，以及测试集逐句预测。

```bash
python train_crf.py \
  --train data/conll2003-train.parquet \
  --validation data/conll2003-validation.parquet \
  --test data/conll2003-test.parquet \
  --output-dir results/e1_rerun

python train_crf.py \
  --train data/conll2003-train.parquet \
  --validation data/conll2003-validation.parquet \
  --test data/conll2003-test.parquet \
  --subset-ids train_10pct_ids.proposed.json --provisional \
  --output-dir results/e3_provisional_rerun
```

A 若采用另一份训练子集，把第二条命令的 `--subset-ids` 指向正式文件，去掉 `--provisional`，将输出目录改为 `results/e3_shared`。接受 JSON ID 数组或 `{"ids": [...]}`，数字 ID 与字符串 ID 都会按原始样本 ID 匹配。

## 交给 A 的预测和模型接口

交付文件为两个实验目录下的 `test_predictions.jsonl`。每行包含原始测试样本的 `id`、`tokens`、`pred_tags`。例如：

```json
{"id":"example","tokens":["New","York"],"pred_tags":["B-LOC","I-LOC"]}
```

全量模型可供 A 接入词级预测。使用 `joblib` 加载本组生成的模型文件。

```python
from joblib import load
from train_crf import predict_tags

model = load("results/e1_full/model.joblib")
tags = predict_tags(["New", "York"], model)
```

本地评分先把没有同类型前驱的 `I-X` 转为 `B-X`，再按 IOB2 严格匹配实体的边界和类型。导出文件保存模型原始标签，便于 A 用小组评分器独立复算。 [CoNLL‑2003 评分说明](https://aclanthology.org/W03-0419.pdf) · [seqeval](https://pypi.org/project/seqeval/)

## 收到 BERT 预测后生成对照错例

请 C 提供同一测试集全部 3,453 句的预测，字段沿用 `id`、`tokens`、`pred_tags`，格式可为 JSONL 或 JSON 数组。脚本检查样本 ID、原始词序列与标签长度，默认从模型预测不同的句子中按种子 42 抽约 20 条，输出 `error_cases.csv` 和完整测试集的 `error_summary.json`。

```bash
python analyze_errors.py \
  --test data/conll2003-test.parquet \
  --crf results/e1_full/test_predictions.jsonl \
  --bert bert_full_test.jsonl \
  --output-dir results/crf_bert_error_analysis
```

省略 `--bert` 可复算全量 CRF 的单模型错例统计。错例类型由实体范围和类型决定，有重叠的未匹配实体按确定性的规则一对一配对，具体规则见报告草稿。

## 复现指标图

`results/crf_f1.png` 对比全量和暂定 10% 训练集的整体及分类 F1。重新绘制时需要 Matplotlib。

```bash
python -m pip install matplotlib==3.9.4
python plot_crf.py results/e1_full/metrics.json results/e3_provisional/metrics.json results/crf_f1.png
```
