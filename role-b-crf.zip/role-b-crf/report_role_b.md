# CRF Baseline and Error Analysis on CoNLL‑2003

## CRF method

We trained a linear-chain conditional random field (CRF) to assign an IOB2 tag to each word in the English CoNLL‑2003 dataset. The features included the lowercased word, capitalization, digit and hyphen indicators, two- and three-character prefixes and suffixes, features from the preceding and following words, and sentence-boundary indicators. The CRF modeled tag transitions and was trained with L‑BFGS for up to 80 iterations. [Sequence Labeling for Parts of Speech and Named Entities](https://web.stanford.edu/~jurafsky/slp3/old_aug24/17.pdf)

We compared three pairs of L1 and L2 coefficients using entity-level micro-F1 on the 3,250-sentence validation set. Both training conditions selected `c1=0.01` and `c2=0.1`. The full condition used all 14,041 training sentences. The provisional 10% condition used 1,404 sentences sampled without replacement with seed 42. Both were evaluated on the same 3,453 test sentences. An entity counted as correct when both token boundaries and the type matched the annotation. An `I-X` prediction without an open entity of type `X` was interpreted as `B-X` before scoring. [CoNLL‑2003 shared task evaluation](https://aclanthology.org/W03-0419.pdf)

## CRF results

| Training condition | Training sentences | Validation micro-F1 | Test precision | Test recall | Test micro-F1 |
|---|---:|---:|---:|---:|---:|
| Full training set | 14,041 | 88.48% | 81.75% | 79.57% | **80.65%** |
| Provisional 10% subset | 1,404 | 77.19% | 74.55% | 68.66% | **71.48%** |

The provisional subset reduced test micro-F1 by 9.16 percentage points, computed from the unrounded scores. Recall fell by 10.91 points and precision by 7.21 points. The 10% row is based on a single sample of the training set and becomes a group comparison once both models use the same confirmed IDs.

| Entity type | Test support | Full CRF F1 | Provisional 10% CRF F1 |
|---|---:|---:|---:|
| PER | 1,617 | 84.18% | 75.54% |
| ORG | 1,661 | 73.69% | 63.06% |
| LOC | 1,668 | 86.08% | 77.06% |
| MISC | 702 | 75.11% | 67.58% |

`ORG` had the lowest F1 in both conditions and the largest decline in the provisional 10% run, at 10.63 points. `LOC` had the highest F1 in both conditions.

[Figure. Overall and per-type CRF F1 on the test set](results/crf_f1.png)

## Full CRF error analysis

The full CRF correctly identified 4,494 of the 5,648 annotated entities. Exact-match recall was 77.48% for one-token entities (2,769/3,574), 85.02% for two-token entities (1,510/1,776), and 72.15% for entities of three or more tokens (215/298). These groups compare exact entity recovery, which includes both boundary and type agreement.

For the error audit, exact matches were removed first. The remaining overlapping spans were paired one-to-one, prioritizing identical boundaries, then identical types, then other overlaps. Within each priority, greater intersection over union ranked first. Leftover gold and predicted spans were counted as misses and spurious predictions, respectively. On the full test set this procedure found 551 type errors, 168 boundary errors, 85 combined boundary and type errors, 350 misses, and 199 spurious predictions.

| Test ID | Gold entity | CRF prediction | Error |
|---|---|---|---|
| `2089` | `Berne Convention` · MISC | `Berne Convention` · ORG | Type |
| `483` | `GOLDEN STATE` · LOC | `GOLDEN` · LOC | Boundary shortened |
| `308` | `Lloyd` · PER | `Lloyd did` · ORG | Boundary and type |
| `808` | `Weah` · PER | — | Missed entity |
| `1886` | — | `Babri` · LOC | Spurious entity |

The examples come from a 20-sentence sample of CRF errors, drawn with seed 42. They illustrate the error categories. The aggregate counts and recall rates above use the full test set.

## CRF and BERT comparison

The paired comparison requires full BERT test predictions aligned to the same 3,453 sample IDs and token sequences. Once available, the analysis will use full-test metrics and the error breakdown for both models, with a fixed-seed sample of 20 sentences where their entity predictions differ. The group will use the confirmed shared training IDs for the 10% comparison.
