# Role C | English named entity recognition with BERT

E2 fine-tunes bert-base-cased on all 14,041 CoNLL-2003 training sentences. E4 starts from the same pretrained checkpoint and uses the 1,404 training IDs shared with the E3 CRF experiment.

| Experiment | Test precision | Test recall | Test entity micro-F1 |
|---|---:|---:|---:|
| E2, full training set | 90.32% | 92.03% | 91.17% |
| E4, shared 10% subset | 83.89% | 86.19% | 85.02% |

## Reproduce the experiments

1. Import C_BERT_NER_Colab_Enterprise.ipynb into Colab Enterprise and connect a GPU runtime (the recorded runs used one Tesla T4).
2. Run the setup and data configuration cells. Place data/train_10pct_ids.json at the SHARED_IDS path printed by the notebook before running E4.
3. Run the training, evaluation and demonstration cells in order. Each condition uses the validation checkpoint with the highest strict entity micro-F1. Runtime, parameters and epoch scores are recorded in results/E2/ and results/E4/.
4. The export cells write model weights and the full prediction handoff to the runtime. The course group shares trained checkpoints separately through member C.

## Prediction files

The repository version stores each test sentence ID and its predicted BIO tags in test_pred_tags.jsonl for each experiment. Match the string ID to the test split at the revision recorded in results/manifest.json for the original tokens. For scoring, interpret an I-X without an open entity of type X as B-X. The group handoff also provides the three-field test_predictions.jsonl files consumed by the shared evaluator.

Dataset and access information: https://huggingface.co/datasets/eriktks/conll2003
